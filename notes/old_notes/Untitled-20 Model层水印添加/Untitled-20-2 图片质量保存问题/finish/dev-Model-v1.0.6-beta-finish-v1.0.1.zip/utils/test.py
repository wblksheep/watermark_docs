from PIL import Image
import io

# 调整尺寸后的图像
resized_image = base_image.resize((width, config['output_height']))

# 在内存中模拟保存为低质量 JPEG 并重新加载
buffer = io.BytesIO()
resized_image.save(buffer, format="JPEG", quality=30)  # 质量设为30（严重压缩）
buffer.seek(0)  # 重置指针
low_quality_image = Image.open(buffer)

# 后续处理可直接使用 low_quality_image