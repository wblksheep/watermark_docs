import glob
import os

from config import ConfigLoader
from utils.basic import generate_watermark

class WatermarkModel:
    def __init__(self):
        self.config = ConfigLoader.load_watermark_config()

    def get_handler(self, wm_type):
        return getattr(self, self.config[wm_type]['handler'])

    def process_image_watermark(self, folder, opacity=50, **kwargs):
        # 具体实现
        print(f"处理图片水印: {folder}, 不透明度: {opacity}")

    def process_text_watermark(self, folder, text="BH", **kwargs):
        # 具体实现
        print(f"处理文字水印: {folder}, 文字内容: {text}")

    @staticmethod
    def process_files(folder_path, watermark_type, opacity=50):
        if not folder_path:
            raise ValueError("请先选择文件夹")

        for file_path in glob.glob(os.path.join(folder_path, "*")):
            if os.path.isfile(file_path):
                basename = os.path.basename(file_path)
                generate_watermark(
                    f"resources/input/{basename}",
                    watermark_type,
                    final_opacity=opacity
                )
                yield basename  # 使用生成器实时反馈处理进度