from abc import abstractmethod

from PySide6.QtWidgets import (
    QMainWindow, QMenuBar, QMenu, QPushButton, QComboBox,
    QVBoxLayout, QWidget, QLabel, QLineEdit, QFileDialog
)
from PySide6.QtGui import QAction
from PySide6.QtCore import Qt, Signal
from config import ConfigLoader
import logging
logger = logging.getLogger(__name__)


class IMainWindow(QMainWindow):
    def __init__(self, parent=None):
        super(IMainWindow, self).__init__(parent)
    @abstractmethod
    def show_folder_dialog(self, default_path) -> str: pass

    @abstractmethod
    def set_folder_path(self, path: str): pass

    @abstractmethod
    def get_folder_path(self) -> str: pass

    @abstractmethod
    def get_opacity_input(self) -> str: pass

class MainWindow(IMainWindow):
    # 定义信号（用于向Presenter传递事件）
    folder_selected = Signal()
    opacity_changed = Signal(int)
    generate_triggered = Signal(int)  # (index, watermark_type)
    menu_clicked = Signal(str)
    toggle_topmost = Signal(bool)

    def __init__(self):
        super().__init__()
        self.setWindowTitle("界面示例")
        self.setGeometry(100, 100, 400, 300)
        self.presenter = None
        self.config = ConfigLoader.load_watermark_config()
        self._init_ui()



    def show_folder_dialog(self, default_path):
        return QFileDialog.getExistingDirectory(self, "选择文件夹", default_path)

    def set_folder_path(self, path):
        self.folder_input.setText(path)

    def get_folder_path(self):
        return self.folder_input.text()

    def get_opacity_input(self):
        return self.opacity_input.text()
    def initAfterInjection(self):
        self.toggle_topmost.emit(True)


    def set_presenter(self, presenter):
        self.presenter = presenter

    def _init_ui(self):

        self._create_menu_bar()
        self._create_main_content()

    def _create_param_inputs(self, params):
        # 根据配置生成对应输入框
        container = QWidget()
        layout = QVBoxLayout()
        for param, value in params.items():
            label = QLabel(param)
            input = QLineEdit(str(value))
            layout.addWidget(label)
            layout.addWidget(input)
        container.setLayout(layout)
        return container

    def get_watermark_params(self, wm_type):
        # 收集用户输入参数
        inputs = self.params_inputs[wm_type]
        return {
            param: input.text()
            for param, input in zip(self.config[wm_type]['params'], inputs.children())
            if isinstance(input, QLineEdit)
        }

    def _bind_handlers(self):
        # 动态绑定配置中的处理器
        for wm_type in self.model.config:
            handler = self._create_handler(wm_type)
            setattr(self, f"handle_{wm_type}", handler)

    def _create_menu_bar(self):
        menu_bar = self.menuBar()

        # 文件菜单
        file_action = QAction("文件", self)
        file_action.triggered.connect(lambda: self.menu_clicked.emit("文件"))
        menu_bar.addAction(file_action)

        # 窗口置顶
        self.always_on_top_action = QAction("取消始终置顶", self)
        self.always_on_top_action.setCheckable(True)
        self.always_on_top_action.setChecked(True)
        self.always_on_top_action.triggered.connect(
            lambda checked: self.toggle_topmost.emit(checked)
        )
        menu_bar.addAction(self.always_on_top_action)

    def _create_main_content(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout()

        # 标签
        label = QLabel("界面示例")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        # # 下拉菜单
        # self.combo_box = QComboBox()
        # # with open("config.yaml", "r", encoding="utf-8") as f:
        # #     try:
        # #         config = yaml.safe_load(f)
        # #     except Exception as e:
        # #         logger.exception(e)
        # #         # raise Exception(e)
        # options = ConfigLoader.load_watermark_config()
        # # print(watermark_options)
        # # self.combo_box.addItems([opt['display'] for opt in options])
        # layout.addWidget(self.combo_box)

        # 动态生成界面元素
        self.combo = QComboBox()
        for wm_type, data in self.config.items():
            self.combo.addItem(data['display'], wm_type)

        self.params_inputs = {
            wm_type: self._create_param_inputs(data['params'])
            for wm_type, data in self.config.items()
        }
        layout.addWidget(self.combo)

        # 文件夹选择
        self.folder_input = QLineEdit()
        self.folder_input.setPlaceholderText("请选择文件夹")
        folder_button = QPushButton("选择文件夹")
        folder_button.clicked.connect(self._emit_folder_selected)
        layout.addWidget(self.folder_input)
        layout.addWidget(folder_button)

        # 不透明度输入
        self.opacity_input = QLineEdit()
        self.opacity_input.setPlaceholderText("请输入不透明度，默认50%")
        layout.addWidget(self.opacity_input)

        # 生成按钮
        generate_btn = QPushButton("生成水印")
        generate_btn.clicked.connect(
            lambda: self.generate_triggered.emit(
                # self.combo_box.currentIndex()
                self.combo.currentIndex()
            )
        )
        layout.addWidget(generate_btn)
        central_widget.setLayout(layout)

    def _emit_folder_selected(self):
        folder = self.folder_selected.emit()
        if folder:
            self.folder_input.text()

    def update_topmost_status(self, is_topmost):
        text = "取消始终置顶" if is_topmost else "始终置顶"
        self.always_on_top_action.setText(text)
