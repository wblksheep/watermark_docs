from PySide6.QtWidgets import QFileDialog
from PySide6.QtCore import QObject, Qt

from config import ConfigLoader

# class WatermarkPresenter:
#     def __init__(self, view, model):
#         self.view = view
#         self.model = model
#         self._bind_handlers()
#
#     def _bind_handlers(self):
#         # 动态绑定配置中的处理器
#         for wm_type in self.model.config:
#             handler = self._create_handler(wm_type)
#             setattr(self, f"handle_{wm_type}", handler)
#
#     def _create_handler(self, wm_type):
#         def handler():
#             folder = self.view.get_folder()
#             params = self._collect_params(wm_type)
#             self.model.get_handler(wm_type)(folder, **params)
#         return handler
#
#     def _collect_params(self, wm_type):
#         # 合并配置默认值与用户输入
#         default_params = self.model.config[wm_type]['params']
#         user_params = self.view.get_watermark_params(wm_type)
#         return {**default_params, **user_params}

class MainPresenter(QObject):
    def __init__(self, view, model):
        super().__init__()
        self.view = view
        self.model = model
        self.view.set_presenter(self)  # 关键：反向设置
        self._connect_signals()
        self.view.initAfterInjection()
        self.options = ConfigLoader.load_watermark_config()
        self._bind_handlers()

    def _bind_handlers(self):
        # 动态绑定配置中的处理器
        for wm_type in self.model.config:
            handler = self._create_handler(wm_type)
            setattr(self, f"handle_{wm_type}", handler)

    def _create_handler(self, wm_type):
        def handler():
            folder = self.view.get_folder_path()
            params = self._collect_params(wm_type)
            self.model.get_handler(wm_type)(folder, **params)
        return handler

    def _collect_params(self, wm_type):
        # 合并配置默认值与用户输入
        default_params = self.model.config[wm_type]['params']
        user_params = self.view.get_watermark_params(wm_type)
        return {**default_params, **user_params}

    def _connect_signals(self):
        # 连接视图信号
        self.view.generate_triggered.connect(self.handle_selection)
        self.view.folder_selected.connect(self.handle_folder_selection)
        self.view.toggle_topmost.connect(self.toggle_window_topmost)
        self.view.menu_clicked.connect(self.on_menu_click)

    def on_menu_click(self, item):
        print(f"点击了菜单项: {item}")



    def handle_folder_selection(self):
        # folder = QFileDialog.getExistingDirectory(self.view, "选择文件夹", "resources/input")
        # if folder:
        #     self.view.folder_input.setText(folder)
        selected_path = self.view.show_folder_dialog("resources/input")
        if selected_path:
            # # 业务逻辑处理（示例）
            # validated_path = self.model.validate_folder(selected_path)
            # self.model.set_workspace(validated_path)

            # 通过接口更新视图
            self.view.set_folder_path(selected_path)


    def toggle_window_topmost(self, is_topmost):
        flags = self.view.windowFlags()
        if is_topmost:
            flags |= Qt.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowStaysOnTopHint
        self.view.setWindowFlags(flags)
        self.view.show()
        self.view.update_topmost_status(is_topmost)

    def _get_watermark_type(self, index):
        if 0 <= index < len(self.options):
            return self.options[index]["value"]
        return "default"

    def handle_selection(self, index):
        handler_name = [wm_type for wm_type, _ in self.options.items()][index]
        handler = getattr(self, f"handle_{handler_name}", self._default_handler)
        # handler = getattr(self, f"{handler_name}", self._default_handler)
        handler()
        # handler = self.options[]

    # def handle_normal_watermark(self):
    #     print("执行正常水印逻辑...")
    #     folder = self.view.get_folder_path()
    #     opacity = self.view.get_opacity_input() or 50
    #     opacity = int(opacity)
    #     if not 0 <= opacity <= 100:
    #         raise ValueError("不透明度需在0-100之间")
    #
    #     for filename in self.model.process_files(folder, watermark_type, opacity):
    #         print(f"已处理: {filename}")  # 可替换为界面状态更新

    def handle_foggy_watermark(self):
        print("执行雾化水印逻辑...")

    def _default_handler(self):
        print("未知选项，使用默认处理")

    def handle_generate(self, index, watermark_type):
        folder = self.view.folder_input.text()
        opacity = self.view.opacity_input.text() or 50
        opacity = int(opacity)
        if not 0 <= opacity <= 100:
            raise ValueError("不透明度需在0-100之间")

        for filename in self.model.process_files(folder, watermark_type, opacity):
            print(f"已处理: {filename}")  # 可替换为界面状态更新
        # try:
        #     opacity = int(opacity)
        #     if not 0 <= opacity <= 100:
        #         raise ValueError("不透明度需在0-100之间")
        #
        #     for filename in self.model.process_files(folder, watermark_type, opacity):
        #         print(f"已处理: {filename}")  # 可替换为界面状态更新
        #
        # except ValueError as e:
        #     print(f"错误: {str(e)}")  # 应更新界面显示错误信息
        # except Exception as e:
        #     print(f"生成失败: {str(e)}")
