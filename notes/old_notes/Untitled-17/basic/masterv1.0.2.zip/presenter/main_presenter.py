from PySide6.QtWidgets import QFileDialog
from PySide6.QtCore import QObject, Qt


class MainPresenter(QObject):
    def __init__(self, view, model):
        super().__init__()
        self.view = view
        self.model = model
        self.view.set_presenter(self)  # 关键：反向设置
        self._connect_signals()
        self.view.initAfterInjection()

    def _connect_signals(self):
        # 连接视图信号
        self.view.generate_triggered.connect(self.handle_generate)
        self.view.folder_selected.connect(self.handle_folder_selection)
        self.view.toggle_topmost.connect(self.toggle_window_topmost)
        self.view.menu_clicked.connect(self.on_menu_click)

    def on_menu_click(self, item):
        print(f"点击了菜单项: {item}")

    def handle_folder_selection(self):
        folder = QFileDialog.getExistingDirectory(self.view, "选择文件夹", "resources/input")
        if folder:
            self.view.folder_input.setText(folder)

    def toggle_window_topmost(self, is_topmost):
        flags = self.view.windowFlags()
        if is_topmost:
            flags |= Qt.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowStaysOnTopHint
        self.view.setWindowFlags(flags)
        self.view.show()
        self.view.update_topmost_status(is_topmost)

    def handle_generate(self, index, watermark_type):
        folder = self.view.folder_input.text()
        opacity = self.view.opacity_input.text() or 50
        opacity = int(opacity)
        if not 0 <= opacity <= 100:
            raise ValueError("不透明度需在0-100之间")

        for filename in self.model.process_files(folder, watermark_type, opacity):
            print(f"已处理: {filename}")  # 可替换为界面状态更新
        # try:
        #     opacity = int(opacity)
        #     if not 0 <= opacity <= 100:
        #         raise ValueError("不透明度需在0-100之间")
        #
        #     for filename in self.model.process_files(folder, watermark_type, opacity):
        #         print(f"已处理: {filename}")  # 可替换为界面状态更新
        #
        # except ValueError as e:
        #     print(f"错误: {str(e)}")  # 应更新界面显示错误信息
        # except Exception as e:
        #     print(f"生成失败: {str(e)}")
