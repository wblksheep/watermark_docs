import glob
import os
from utils.basic import generate_watermark

class WatermarkModel:
    @staticmethod
    def process_files(folder_path, watermark_type, opacity=50):
        if not folder_path:
            raise ValueError("请先选择文件夹")

        for file_path in glob.glob(os.path.join(folder_path, "*")):
            if os.path.isfile(file_path):
                basename = os.path.basename(file_path)
                generate_watermark(
                    f"resources/input/{basename}",
                    watermark_type,
                    final_opacity=opacity
                )
                yield basename  # 使用生成器实时反馈处理进度