import yaml
import logging
from pathlib import Path
logger = logging.getLogger(__name__)
class ViewConfigLoader:
    @staticmethod
    def load_view_config():
        try:
            config_path = Path(__file__).parent.parent / "config/view.yaml"
            with open(config_path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f)
        except Exception as e:
            logger.exception("View config loading failed")
            return {}  # 返回空配置保证可降级运行