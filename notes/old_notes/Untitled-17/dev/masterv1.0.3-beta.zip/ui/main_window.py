from PySide6.QtWidgets import (
    QMainWindow, QMenuBar, QMenu, QPushButton, QComboBox,
    QVBoxLayout, QWidget, QLabel, QLineEdit, QHBoxLayout
)
from PySide6.QtGui import QAction
from PySide6.QtCore import Qt, Signal
from config import ConfigLoader
from configloader.viewconfigloader import ViewConfigLoader
import logging

logger = logging.getLogger(__name__)


class MainWindow(QMainWindow):
    # 新增组合框选择信号
    combo_selection_changed = Signal(int)


    # 定义信号（用于向Presenter传递事件）
    folder_selected = Signal()
    opacity_changed = Signal(int)
    # generate_triggered = Signal(int)  # (index, watermark_type)
    # 修改后的生成信号
    generate_triggered = Signal(str)  # 传递value值而不是index
    menu_clicked = Signal(str)
    toggle_topmost = Signal(bool)

    def __init__(self):
        super().__init__()
        self.config = ViewConfigLoader.load_view_config()
        self._init_window_properties()
        self._init_ui()

        # self.setWindowTitle("界面示例")
        # self.setGeometry(100, 100, 400, 300)
        # self.presenter = None
        # self._init_ui()

    def _init_ui(self):
        self._create_menu_bar()
        self._create_main_content()

    def _init_window_properties(self):
        window_config = self.config.get("window", {})
        self.setWindowTitle(window_config.get("title", "默认标题"))
        self.setGeometry(100, 100,
                         window_config.get("width", 400),
                         window_config.get("height", 300))

    def initAfterInjection(self):
        self.toggle_topmost.emit(True)

    def set_presenter(self, presenter):
        self.presenter = presenter

    def _create_menu_bar(self):
        menu_bar = self.menuBar()
        menu_config = self.config.get("components", {}).get("menu_bar", {})

        for item in menu_config.get("items", []):
            if item["type"] == "menu":
                self._create_menu_item(menu_bar, item)
            elif item["type"] == "checkable_action":
                self._create_checkable_action(menu_bar, item)
        # menu_bar = self.menuBar()
        #
        # # 文件菜单
        # file_action = QAction("文件", self)
        # file_action.triggered.connect(lambda: self.menu_clicked.emit("文件"))
        # menu_bar.addAction(file_action)
        #
        # # 窗口置顶
        # self.always_on_top_action = QAction("取消始终置顶", self)
        # self.always_on_top_action.setCheckable(True)
        # self.always_on_top_action.setChecked(True)
        # self.always_on_top_action.triggered.connect(
        #     lambda checked: self.toggle_topmost.emit(checked)
        # )
        # menu_bar.addAction(self.always_on_top_action)

    def _create_menu_item(self, parent, config):
        menu = QMenu(config["text"], self)
        parent.addMenu(menu)
        # 可扩展子菜单项
        return menu

    def _create_checkable_action(self, parent, config):
        action = QAction(config["text"], self)
        action.setCheckable(True)
        action.setChecked(config.get("checked", False))
        action.triggered.connect(
            lambda checked: self.menu_clicked.emit(config["action_id"])
        )
        parent.addAction(action)
        setattr(self, f"{config['action_id']}_action", action)

    def _create_main_content(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        panel_config = self.config.get("components", {}).get("main_panel", {})
        layout = QVBoxLayout()

        # 标题标签
        # self._create_title_label(layout, panel_config)

        # 动态创建配置化组件
        self._create_combo_box(layout, panel_config.get("combo_box", {}))
        self._create_folder_input(layout, panel_config.get("folder_input", {}))
        self._create_opacity_input(layout, panel_config.get("opacity_input", {}))
        self._create_generate_btn(layout, panel_config.get("generate_btn", {}))

        central_widget.setLayout(layout)

        # central_widget = QWidget()
        # self.setCentralWidget(central_widget)
        # layout = QVBoxLayout()
        #
        # # 标签
        # label = QLabel("界面示例")
        # label.setAlignment(Qt.AlignCenter)
        # layout.addWidget(label)
        #
        # # 下拉菜单
        # self.combo_box = QComboBox()
        # # with open("view.yaml", "r", encoding="utf-8") as f:
        # #     try:
        # #         config = yaml.safe_load(f)
        # #     except Exception as e:
        # #         logger.exception(e)
        # #         # raise Exception(e)
        # options = ConfigLoader.load_watermark_config()
        # # print(watermark_options)
        # self.combo_box.addItems([opt['display'] for opt in options])
        # layout.addWidget(self.combo_box)
        #
        # # 文件夹选择
        # self.folder_input = QLineEdit()
        # self.folder_input.setPlaceholderText("请选择文件夹")
        # folder_button = QPushButton("选择文件夹")
        # folder_button.clicked.connect(self._emit_folder_selected)
        # layout.addWidget(self.folder_input)
        # layout.addWidget(folder_button)
        #
        # # 不透明度输入
        # self.opacity_input = QLineEdit()
        # self.opacity_input.setPlaceholderText("请输入不透明度，默认50%")
        # layout.addWidget(self.opacity_input)
        #
        # # 生成按钮
        # generate_btn = QPushButton("生成水印")
        # generate_btn.clicked.connect(
        #     lambda: self.generate_triggered.emit(
        #         self.combo_box.currentIndex()
        #     )
        # )
        # layout.addWidget(generate_btn)
        # central_widget.setLayout(layout)
    # def _create_title_label(self, layout, config):


    def _create_combo_box(self, layout, config):
        self.combo_box = QComboBox()
        for opt in config.get("options", []):
            self.combo_box.addItem(opt["display"], opt["value"])
        if config.get("default_index") is not None:
            self.combo_box.setCurrentIndex(config["default_index"])
        if "width" in config:
            self.combo_box.setFixedWidth(config["width"])
        layout.addWidget(self.combo_box)
        self.combo_box.currentIndexChanged.connect(
            lambda idx: self.combo_selection_changed.emit(idx)
        )

    def _create_folder_input(self, layout, config):
        container = QWidget()
        sub_layout = QHBoxLayout()

        self.folder_input = QLineEdit()
        self.folder_input.setPlaceholderText(config.get("placeholder", ""))

        folder_btn = QPushButton(config.get("button_text", ""))
        folder_btn.clicked.connect(self._emit_folder_selected)

        sub_layout.addWidget(self.folder_input)
        sub_layout.addWidget(folder_btn)
        container.setLayout(sub_layout)
        layout.addWidget(container)

    def _create_opacity_input(self, layout, config):
        self.opacity_input = QLineEdit()
        self.opacity_input.setPlaceholderText(config.get("placeholder", ""))
        layout.addWidget(self.opacity_input)

    def _create_generate_btn(self, layout, config):
        generate_btn = QPushButton(config.get("text", ""))
        generate_btn.clicked.connect(
            lambda: self.generate_triggered.emit(
                self.combo_box.currentData()  # 传递存储的value值
            )
        )
        layout.addWidget(generate_btn)

    def _emit_folder_selected(self):
        folder = self.folder_selected.emit()
        if folder:
            self.folder_input.text()

    def update_topmost_status(self, is_topmost):
        text = "取消始终置顶" if is_topmost else "始终置顶"
        self.always_on_top_action.setText(text)
